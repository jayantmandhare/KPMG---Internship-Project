#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


# In[9]:


get_ipython().run_line_magic('pwd', '')


# In[10]:


df= pd.read_excel('kpmg_raw_transactions.xlsx')


# In[11]:


print(df)


# In[12]:


print(df.product_id)


# In[13]:


print(df.isnull().sum())


# In[14]:



df.columns


# In[15]:


df.shape


# In[16]:


df.info()


# In[17]:


df.duplicated().sum()


# In[18]:


df.loc[df.duplicated(),:]


# In[ ]:




