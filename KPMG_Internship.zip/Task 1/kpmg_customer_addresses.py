#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


# In[3]:


get_ipython().run_line_magic('pwd', '')


# In[5]:


df=pd.read_excel('C:\\Users\\Archita Keni\\kpmg_customeraddress.xlsx')
print(df)


# In[6]:


sudo pip install pygeocoder


# In[7]:


import geocoder


# In[8]:


from i18naddress import InvalidAddress, normalize_address


# In[10]:


from OpenSSL import SSL 
 
print (SSL._CERTIFICATE_PATH_LOCATIONS)


# In[11]:


df.columns()


# In[12]:


df.columns


# In[13]:


print(df.isnull().sum())


# In[14]:


df.info()


# In[15]:


df.duplicated().sum()


# In[16]:


df.loc[df.duplicated(),:]


# In[ ]:




