#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


# In[2]:


df=read_excel(r'C:\Users\Archita Keni\Desktop\jOBS\KPMG INTERNSHIP\kpmg_raw_transactions)


# In[3]:


df=pd.read_exce('kpmg_raw_data')


# In[4]:


df=pd.read_exce('kpmg_raw_data.xlsx')


# In[5]:


df=pd.read_excel('kpmg_raw_data.xlsx')


# In[6]:


df=pd.read_excel('C:\Users\Archita Keni\Desktop\jOBS\KPMG INTERNSHIP\kpmg_raw_transactions.xlsx')


# In[7]:


df= pd.read_excel('kpmg_raw_transactions.xlsx')


# In[8]:


df= pd.read_excel('kpmg_raw_transactions.xlsx')


# In[9]:


get_ipython().run_line_magic('pwd', '')


# In[10]:


df= pd.read_excel('kpmg_raw_transactions.xlsx')


# In[11]:


print(df)


# In[12]:


print(df.product_id)


# In[13]:


print(df.isnull().sum())


# In[14]:



df.columns


# In[15]:


df.shape


# In[16]:


df.info()


# In[17]:


df.duplicated().sum()


# In[18]:


df.loc[df.duplicated(),:]


# In[ ]:




