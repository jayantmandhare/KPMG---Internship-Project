#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


# In[4]:


df=pd.read_excel("C:\\Users\\Archita Keni\\kpmg_customerdemographic.xlsx")


# In[5]:


print(df)


# In[6]:


df.columns


# In[7]:


print(df.isnull().sum())


# In[8]:


df.info()


# In[9]:


df.shape


# In[10]:


df.duplicated().sum()


# In[ ]:




